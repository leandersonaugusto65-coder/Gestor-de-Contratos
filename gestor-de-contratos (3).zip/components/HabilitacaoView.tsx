
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import JSZip from 'jszip';
import { ArrowDownTrayIcon } from './icons/ArrowDownTrayIcon';
import { ArrowUpTrayIcon } from './icons/ArrowUpTrayIcon';
import { XMarkIcon } from './icons/XMarkIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { ArrowPathIcon } from './icons/ArrowPathIcon';
import { ArchiveBoxIcon } from './icons/ArchiveBoxIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { FolderIcon } from './icons/FolderIcon';
import { TrashIcon } from './icons/TrashIcon';
import { ShieldCheckIcon } from './icons/ShieldCheckIcon';
import { BanknotesIcon } from './icons/BanknotesIcon';
import { GlobeAltIcon } from './icons/GlobeAltIcon';
import { Squares2x2Icon } from './icons/Squares2x2Icon';
import { BookOpenIcon } from './icons/BookOpenIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { PaperClipIcon } from './icons/PaperClipIcon';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';
import { PencilIcon } from './icons/PencilIcon';
import { CheckIcon } from './icons/CheckIcon';
import type { Certidao, HabilitacaoData, ManagedFile } from '../types';

// --- TYPES ---
type CertidaoStatus = 'Ativa' | 'Inativa' | 'Válida' | 'A Vencer' | 'Vence Hoje' | 'Vencida' | 'Não Emitida' | 'Diária';
type CertidaoStatusInfo = { text: CertidaoStatus; color: string; };

const initialHabilitacaoData: HabilitacaoData = {
  certidoes: { estadual: {}, federal: {}, municipal: {}, distrital: {}, fgts: {}, trabalhista: {}, estadualTributaria: {}, falencia: {}, correcional: {} },
  contabilidade: [], ctf: [], catalogo: [], contratoSocial: [], capacidadeTecnica: [], outros: []
};

// --- STATIC DATA ---
const cadespData = {
  ie: '688.658.049.116',
  cnpj: '27.454.615/0001-44',
  nomeEmpresarial: '27.454.615 DONIMARA RIBEIRO DO CARMO',
  situacao: 'Ativo',
  dataInscricao: '19/04/2022',
};

// --- HELPER COMPONENTS ---
const DataField: React.FC<{ label: string; value: React.ReactNode; className?: string }> = ({ label, value, className }) => (
    <div className={`bg-black/20 p-4 rounded-2xl border border-gray-800/60 ${className}`}>
        <p className="text-[10px] font-bold text-gray-500 uppercase mb-1 tracking-wider">{label}</p>
        <div className="text-gray-200 font-medium text-sm">{value}</div>
    </div>
);

const StatusBadge: React.FC<{ status: CertidaoStatusInfo }> = ({ status }) => (
    <span className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-full border-2 ${status.color}`}>
        {status.text}
    </span>
);

// --- LOGIC ---
const getCertidaoStatus = (expiryDate: string | null | undefined, certKey?: string): CertidaoStatusInfo => {
    if (!expiryDate) {
        if (certKey === 'falencia') {
            return { text: 'Diária', color: 'border-yellow-600/50 bg-yellow-600/10 text-yellow-500' };
        }
        return { text: 'Não Emitida', color: 'border-gray-700 bg-gray-800 text-gray-500' };
    }
    
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const vencimento = new Date(`${expiryDate}T00:00:00`);
    vencimento.setHours(0,0,0,0);

    const diffTime = vencimento.getTime() - hoje.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { text: 'Vencida', color: 'border-red-500/50 bg-red-500/10 text-red-400' };
    if (diffDays === 0) return { text: 'Vence Hoje', color: 'border-orange-500/50 bg-orange-500/10 text-orange-400' };
    if (diffDays > 0 && diffDays <= 5) return { text: 'A Vencer', color: 'border-yellow-500/50 bg-yellow-600/10 text-yellow-400' };
    return { text: 'Válida', color: 'border-green-500/50 bg-green-500/10 text-green-400' };
};

const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return 'Não definida';
    return new Intl.DateTimeFormat('pt-BR').format(new Date(`${dateString}T00:00:00`));
};

// --- SUB-COMPONENTS ---
const CertidaoDetailView: React.FC<{ 
    title: string; 
    certKey: string;
    certidao: Certidao; 
    onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void; 
    onRemoveFile: () => void; 
    onAutoUpdate: () => void; 
    onUpdateDates: (dates: { issueDate: string | null, expiryDate: string | null }) => void;
    isProcessingAI: boolean; 
    isUpdating: boolean; 
    statusOverride?: CertidaoStatusInfo; 
    children?: React.ReactNode; 
}> = ({ title, certKey, certidao, onFileUpload, onRemoveFile, onAutoUpdate, onUpdateDates, isProcessingAI, isUpdating, statusOverride, children }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const status = statusOverride || getCertidaoStatus(certidao?.expiryDate, certKey);
    const [isEditingDates, setIsEditingDates] = useState(false);
    const [editedDates, setEditedDates] = useState({ issueDate: certidao?.issueDate || '', expiryDate: certidao?.expiryDate || '' });

    useEffect(() => {
        setEditedDates({ issueDate: certidao?.issueDate || '', expiryDate: certidao?.expiryDate || '' });
    }, [certidao]);

    const handleDownload = () => {
        if (!certidao?.fileData || !certidao?.fileName) return;
        const link = document.createElement('a');
        link.href = certidao.fileData;
        link.download = certidao.fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleSaveDates = () => {
        onUpdateDates({
            issueDate: editedDates.issueDate || null,
            expiryDate: editedDates.expiryDate || null
        });
        setIsEditingDates(false);
    };
    
    return (
        <div className="animate-fade-in space-y-8">
            <div className="bg-gray-900 rounded-3xl border border-gray-800 shadow-xl p-8">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
                    <div className="flex items-center gap-4">
                        <h3 className="text-xl font-bold text-white">{title}</h3>
                        <StatusBadge status={status} />
                    </div>
                    <div className="flex items-center gap-2">
                        {isProcessingAI ? ( <div className="flex items-center gap-2 text-sm text-yellow-500 font-bold"><SpinnerIcon className="w-5 h-5 animate-spin" /><span>Analisando PDF...</span></div> ) : ( <>
                                <button onClick={onAutoUpdate} disabled={isUpdating} className="flex items-center gap-2 bg-yellow-600 hover:bg-yellow-700 disabled:bg-yellow-800 text-black font-bold py-2 px-4 rounded-lg transition-all text-sm">{isUpdating ? <SpinnerIcon className="w-4 h-4 animate-spin" /> : <ArrowPathIcon className="w-4 h-4" />}{isUpdating ? 'Buscando...' : 'Obter via Link/IA'}</button>
                                {!certidao?.fileData ? ( <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm"><ArrowUpTrayIcon className="w-4 h-4" /> Anexar PDF</button> ) : ( <>
                                        <button onClick={handleDownload} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm"><ArrowDownTrayIcon className="w-4 h-4" /> Baixar</button>
                                        <button onClick={() => fileInputRef.current?.click()} className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors" title="Substituir PDF"><ArrowUpTrayIcon className="w-5 h-5" /></button>
                                </> )}
                        </> )}
                         <input type="file" ref={fileInputRef} onChange={onFileUpload} accept="application/pdf" className="hidden" />
                    </div>
                </div>

                {!isEditingDates ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <DataField label="Data de Emissão" value={<p className="font-mono">{formatDate(certidao?.issueDate)}</p>} />
                        <DataField label="Data de Vencimento" value={<p className="font-mono">{formatDate(certidao?.expiryDate)}</p>} />
                    </div>
                ) : (
                    <div className="bg-black/20 p-4 rounded-2xl border border-yellow-500/30 grid grid-cols-1 sm:grid-cols-2 gap-4 animate-fade-in">
                        <div>
                             <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Data de Emissão</label>
                             <input type="date" value={editedDates.issueDate} onChange={(e) => setEditedDates(p => ({...p, issueDate: e.target.value}))} className="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white focus:border-yellow-500 outline-none" />
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Data de Vencimento</label>
                            <input type="date" value={editedDates.expiryDate} onChange={(e) => setEditedDates(p => ({...p, expiryDate: e.target.value}))} className="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white focus:border-yellow-500 outline-none" />
                        </div>
                    </div>
                )}

                <div className="mt-4 flex justify-end gap-2">
                    {isEditingDates ? (<>
                        <button onClick={() => setIsEditingDates(false)} className="flex items-center gap-2 text-gray-400 hover:text-white font-bold py-2 px-4 rounded-lg transition-all text-sm bg-gray-800 border border-gray-700 hover:bg-gray-700"><XMarkIcon className="w-4 h-4"/> Cancelar</button>
                        <button onClick={handleSaveDates} className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm shadow-lg"><CheckIcon className="w-4 h-4"/> Salvar Datas</button>
                    </>) : (<>
                        {!isProcessingAI && <button onClick={() => setIsEditingDates(true)} className="flex items-center gap-2 text-gray-400 hover:text-yellow-500 font-bold py-2 px-4 rounded-lg transition-all text-sm hover:bg-gray-800"><PencilIcon className="w-4 h-4"/> Editar Datas</button>}
                    </>)}
                </div>

                {certidao?.fileName && ( <div className="mt-4 bg-black/20 p-3 rounded-lg border border-gray-800/60 flex justify-between items-center text-sm">
                        <p className="text-gray-300 font-medium truncate">Arquivo original: <span className="font-mono text-cyan-400">{certidao.fileName}</span></p>
                        <button onClick={onRemoveFile} className="p-1 text-gray-500 hover:text-red-400" title="Remover anexo"><XMarkIcon className="w-4 h-4"/></button>
                    </div>
                )}
            </div>
            {children}
        </div>
    );
};

const FileCategoryView: React.FC<{
    title: string;
    files: ManagedFile[];
    onAddFile: (file: File) => void;
    onRemoveFile: (fileId: number) => void;
    onUpdateFile: (fileId: number, description: string) => void;
}> = ({ title, files, onAddFile, onRemoveFile, onUpdateFile }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleDownload = (file: ManagedFile) => {
        if (!file.fileData || !file.fileName) return;
        const link = document.createElement('a');
        link.href = file.fileData;
        link.download = file.fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-gray-900 rounded-3xl border border-gray-800 shadow-xl p-8 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <h3 className="text-xl font-bold text-white">{title}</h3>
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm"
                >
                    <ArrowUpTrayIcon className="w-4 h-4" /> Anexar Arquivo(s)
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={(e) => {
                        if (e.target.files) {
                            Array.from(e.target.files).forEach(file => onAddFile(file));
                        }
                        e.target.value = ''; // Reset input
                    }} 
                    multiple 
                    className="hidden" 
                />
            </div>
            {files.length > 0 ? (
                <div className="space-y-4">
                    {files.map(file => (
                        <div key={file.id} className="bg-black/20 p-4 rounded-2xl border border-gray-800/60 flex flex-col sm:flex-row items-start sm:items-center gap-4">
                            <DocumentTextIcon className="w-6 h-6 text-cyan-500 flex-shrink-0 mt-1 sm:mt-0" />
                            <div className="flex-grow">
                                <p className="text-sm text-gray-200 font-bold truncate">{file.fileName}</p>
                                <input 
                                    type="text"
                                    value={file.description}
                                    onChange={(e) => onUpdateFile(file.id, e.target.value)}
                                    placeholder="Adicionar descrição..."
                                    className="w-full bg-transparent text-xs text-gray-400 focus:text-white outline-none border-b border-b-transparent focus:border-b-yellow-500 transition-colors"
                                />
                            </div>
                            <div className="flex items-center gap-2 self-end sm:self-center">
                                <button onClick={() => handleDownload(file)} className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors" title="Baixar">
                                    <ArrowDownTrayIcon className="w-5 h-5" />
                                </button>
                                <button onClick={() => onRemoveFile(file.id)} className="p-2 bg-gray-700 hover:bg-red-500/20 text-gray-400 hover:text-red-400 rounded-lg transition-colors" title="Remover">
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-10 border-2 border-dashed border-gray-800 rounded-2xl">
                    <FolderIcon className="w-10 h-10 text-gray-700 mx-auto mb-2" />
                    <p className="text-gray-500 text-sm">Nenhum arquivo nesta categoria.</p>
                </div>
            )}
        </div>
    );
};

// --- MAIN COMPONENT ---
export const HabilitacaoView: React.FC<{ data: HabilitacaoData | null; onUpdate: (data: HabilitacaoData) => void; }> = ({ data, onUpdate }) => {
    const [activeCategory, setActiveCategory] = useState('certidoes');
    const [selectedCertidaoKey, setSelectedCertidaoKey] = useState<string | null>(null);
    const [isProcessingAI, setIsProcessingAI] = useState<string | null>(null);
    const [isSearchingLink, setIsSearchingLink] = useState<string | null>(null);
    const [isZipping, setIsZipping] = useState(false);
    
    const habilitacaoData = useMemo(() => ({ ...initialHabilitacaoData, ...(data || {}) }), [data]);
    
    const categoryConfig = {
        certidoes: { label: "Certidões", icon: <ShieldCheckIcon /> },
        contabilidade: { label: "Contabilidade", icon: <BanknotesIcon /> },
        ctf: { label: "CTF", icon: <GlobeAltIcon /> },
        catalogo: { label: "Catálogo", icon: <Squares2x2Icon /> },
        contratoSocial: { label: "Contrato Social", icon: <BookOpenIcon /> },
        capacidadeTecnica: { label: "Cap. Técnica", icon: <BriefcaseIcon /> },
        outros: { label: "Outros", icon: <PaperClipIcon /> },
        consolidacao: { label: "Consolidação", icon: <ArchiveBoxIcon /> },
    };

    const certidaoTabConfig = {
        estadual: { label: "Inscrição Estadual" }, 
        federal: { label: "Certidão Federal" }, 
        municipal: { label: "Certidão Municipal" },
        distrital: { label: "Certidão Estadual (dívida ativa)" }, 
        estadualTributaria: { label: "Certidão Estadual (débito tributário)" },
        falencia: { label: "Certidão de Falência" },
        correcional: { label: "Certidão Correcional (CGU)" },
        fgts: { label: "FGTS" }, 
        trabalhista: { label: "Certidão Trabalhista" },
    };
    
    const handleUpdate = (updates: Partial<HabilitacaoData>) => onUpdate({ ...habilitacaoData, ...updates });
    const handleUpdateCertidao = (tab: string, updates: Partial<Certidao>) => {
        const currentCerts = habilitacaoData.certidoes || {};
        handleUpdate({ 
          certidoes: { 
            ...currentCerts, 
            [tab]: { ...(currentCerts[tab as keyof typeof currentCerts] || {}), ...updates } 
          } 
        });
    };

    const handleAddFile = async (category: keyof HabilitacaoData, file: File) => {
        const reader = new FileReader();
        reader.onload = () => {
            const newFile: ManagedFile = { id: Date.now(), fileData: reader.result as string, fileName: file.name, description: '' };
            const currentFiles = habilitacaoData[category] as ManagedFile[];
            handleUpdate({ [category]: [...currentFiles, newFile] } as any);
        };
        reader.readAsDataURL(file);
    };

    const handleRemoveFile = (category: keyof HabilitacaoData, fileId: number) => {
        const currentFiles = habilitacaoData[category] as ManagedFile[];
        handleUpdate({ [category]: currentFiles.filter(f => f.id !== fileId) } as any);
    };
    
    const handleUpdateFile = (category: keyof HabilitacaoData, fileId: number, description: string) => {
        const currentFiles = habilitacaoData[category] as ManagedFile[];
        handleUpdate({ [category]: currentFiles.map(f => f.id === fileId ? { ...f, description } : f) } as any);
    };

    const handleAutoUpdate = async (tabKey: string) => {
        if (tabKey === 'trabalhista') {
            window.open('https://cndt-certidao.tst.jus.br/inicio.faces', '_blank');
            return;
        }
        if (tabKey === 'federal') {
            window.open('https://servicos.receitafederal.gov.br/servico/certidoes/#/home/cnpj', '_blank');
            return;
        }
        if (tabKey === 'municipal') {
            window.open('https://taubate.meumunicipio.digital/ords/taubate/f?p=1666:LOGIN::::::', '_blank');
            return;
        }
        if (tabKey === 'distrital') {
            window.open('https://www.dividaativa.pge.sp.gov.br/sc/pages/crda/emitirCrda.jsf?param=772', '_blank');
            return;
        }
        if (tabKey === 'estadualTributaria') {
            window.open('https://www10.fazenda.sp.gov.br/CertidaoNegativaDeb/Pages/EmissaoCertidaoNegativa.aspx', '_blank');
            return;
        }
        if (tabKey === 'falencia') {
            window.open('https://esaj.tjsp.jus.br/sco/abrirCadastro.do', '_blank');
            return;
        }
        if (tabKey === 'correcional') {
            window.open('https://certidoes.cgu.gov.br/', '_blank');
            return;
        }

        setIsSearchingLink(tabKey);
        try {
            // Fix: Removed JSON mode and schema because combining it with googleSearch is not recommended per Gemini API guidelines.
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Encontre o link oficial e direto do governo para emitir a "Certidão de ${tabKey}" para o CNPJ ${cadespData.cnpj}. Retorne apenas a URL direta do serviço de emissão.`,
                config: { tools: [{googleSearch: {}}] }
            });
            // Fix: Extract URL from text response using regex instead of parsing as JSON.
            const urlMatch = response.text?.match(/https?:\/\/[^\s"']+/);
            if (urlMatch) window.open(urlMatch[0], '_blank');
            else alert('Não foi possível encontrar o link de emissão automática. Você pode anexar o PDF manualmente.');
        } catch (error) { console.error(error); alert('Ocorreu um erro ao buscar o link via IA.'); }
        finally { setIsSearchingLink(null); }
    };

    const extractDatesWithAI = async (base64Data: string, certidaoType: string): Promise<{ issueDate: string | null, expiryDate: string | null }> => {
        let promptText = `Analise esta certidão. Extraia a data de emissão e a data de validade em formato "YYYY-MM-DD". Retorne JSON com chaves "issueDate" e "expiryDate". Se uma data não for encontrada, retorne null.`;
    
        if (certidaoType === 'fgts') {
            promptText = `Este documento é um Certificado de Regularidade do FGTS (CRF) brasileiro.
            Encontre a data de validade que está explicitamente rotulada como "Validade:" (geralmente no final, abaixo de "Certificação").
            Encontre a data de emissão que está rotulada como "Data de emissão" ou "Emissão".
            Retorne as datas estritamente no formato YYYY-MM-DD.
            Se não encontrar, retorne null.`;
        }
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const modelToUse = 'gemini-3-pro-preview';
            
            const response = await ai.models.generateContent({
                model: modelToUse, 
                contents: { parts: [{ inlineData: { mimeType: 'application/pdf', data: base64Data } }, { text: promptText }] },
                config: { 
                    responseMimeType: 'application/json', 
                    responseSchema: { 
                        type: Type.OBJECT, 
                        properties: { 
                            issueDate: { type: Type.STRING, nullable: true }, 
                            expiryDate: { type: Type.STRING, nullable: true } 
                        } 
                    } 
                }
            });
            const result = JSON.parse(response.text || '{}');
            return { issueDate: result.issueDate || null, expiryDate: result.expiryDate || null };
        } catch (error) { 
            console.error("AI Date Extraction Error:", error); 
            alert("A IA não conseguiu ler as datas automaticamente. Você pode preenchê-las manualmente usando o botão 'Editar Datas'.");
            return { issueDate: null, expiryDate: null }; 
        }
    };

    const handleFileUploadCertidao = async (e: React.ChangeEvent<HTMLInputElement>, tab: string) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setIsProcessingAI(tab);
        try {
            const reader = new FileReader();
            const fileData = await new Promise<string>((resolve) => { reader.onload = () => resolve(reader.result as string); reader.readAsDataURL(file); });
            const dates = await extractDatesWithAI(fileData.split(',')[1], tab);
            handleUpdateCertidao(tab, { fileData, fileName: file.name, ...dates });
        } catch (error) { console.error(error); }
        finally { setIsProcessingAI(null); }
        e.target.value = '';
    };

    const handleDownloadAll = async () => {
        setIsZipping(true);
        const zip = new JSZip();
        const sanitize = (name: string) => name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9-._ ]/g, '').trim();
        
        let fileCount = 0;

        const certsFolder = zip.folder(sanitize(categoryConfig.certidoes.label));
        for (const [key, certValue] of Object.entries(habilitacaoData.certidoes || {})) {
            const cert = certValue as Certidao;
            if (cert && cert.fileData && cert.fileName) {
                const ext = cert.fileName.split('.').pop() || 'pdf';
                const label = certidaoTabConfig[key as keyof typeof certidaoTabConfig]?.label || key;
                const newName = `${sanitize(label)}.${ext}`;
                certsFolder?.file(newName, cert.fileData.split(',')[1], { base64: true });
                fileCount++;
            }
        }
        
        for (const catKey of Object.keys(categoryConfig)) {
            if (catKey === 'certidoes' || catKey === 'consolidacao') continue;
            const files = habilitacaoData[catKey as keyof typeof habilitacaoData] as ManagedFile[];
            if (files && files.length > 0) {
                const folder = zip.folder(sanitize(categoryConfig[catKey as keyof typeof categoryConfig].label));
                files.forEach(file => {
                    if (file.fileData && file.fileName) {
                        folder?.file(sanitize(file.fileName), file.fileData.split(',')[1], { base64: true });
                        fileCount++;
                    }
                });
            }
        }

        if (fileCount === 0) { alert('Nenhum documento para consolidar.'); setIsZipping(false); return; }

        try {
            const content = await zip.generateAsync({ type: 'blob' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(content);
            link.download = `Habilitacao_Oficina_da_Arte_${new Date().toISOString().slice(0, 10)}.zip`;
            link.click();
            URL.revokeObjectURL(link.href);
        } catch (error) { console.error(error); alert('Erro ao gerar .zip'); }
        finally { setIsZipping(false); }
    };
    
    const NavButton: React.FC<{ label: string; icon: any; isActive: boolean; onClick: () => void; }> = ({ label, icon, isActive, onClick }) => (
        <button
            onClick={onClick}
            className={`group relative flex flex-col items-center justify-center gap-2 p-3 text-center transition-all duration-300 rounded-2xl border-2 overflow-hidden w-full ${
                isActive 
                ? 'bg-yellow-600/10 border-yellow-500 shadow-[0_0_20px_rgba(202,138,4,0.2)]' 
                : 'bg-gray-900/40 border-gray-800 text-gray-500 hover:border-gray-700 hover:bg-gray-800/60'
            }`}
        >
            <div className={`transition-transform duration-300 group-hover:scale-110 ${isActive ? 'text-yellow-500' : 'text-gray-600 group-hover:text-gray-400'}`}>
                {React.cloneElement(icon, { className: 'w-7 h-7' })}
            </div>
            <span className={`text-[10px] font-bold uppercase tracking-wider transition-colors duration-300 ${isActive ? 'text-white' : 'text-gray-500 group-hover:text-gray-300'}`}>
                {label}
            </span>
        </button>
    );
    
    const renderContent = () => {
        if (activeCategory === 'consolidacao') {
            return (
                <div className="bg-gray-900 rounded-3xl border border-gray-800 shadow-xl p-8">
                    <div className="flex items-center gap-4 mb-6"><ArchiveBoxIcon className="w-8 h-8 text-yellow-500" /><h3 className="text-xl font-bold text-white">Consolidar Documentos</h3></div>
                    <p className="text-sm text-gray-400 mb-6 max-w-2xl">Agrupe todos os documentos anexados em um único arquivo .zip, organizado em pastas por categoria.</p>
                    <div className="bg-black/20 p-6 rounded-2xl border border-gray-800/60 mb-8 space-y-4">
                        {Object.entries(habilitacaoData).map(([catKey, data]) => {
                            if (catKey === 'certidoes') {
                                const certs = Object.entries(data as object).filter(([_, c]) => c && (c as Certidao).fileName);
                                if (certs.length === 0) return null;
                                return (
                                    <div key={catKey}>
                                        <h4 className="text-xs font-bold text-yellow-600 uppercase tracking-widest mb-2">{categoryConfig['certidoes'].label}</h4>
                                        <ul className="space-y-1 text-sm list-disc list-inside">
                                            {certs.map(([key, certValue]: any, i) => {
                                                const cert = certValue as Certidao;
                                                const label = certidaoTabConfig[key as keyof typeof certidaoTabConfig]?.label || key;
                                                const ext = cert.fileName ? cert.fileName.split('.').pop() || 'pdf' : 'pdf';
                                                return <li key={i} className="text-gray-300"><span className="text-cyan-400 font-mono text-xs">{label}.{ext}</span></li>
                                            })}
                                        </ul>
                                    </div>
                                );
                            }

                            const files = (data as ManagedFile[]).filter(f => f.fileName);
                            if (files.length === 0) return null;
                            return ( <div key={catKey}>
                                <h4 className="text-xs font-bold text-yellow-600 uppercase tracking-widest mb-2">{categoryConfig[catKey as keyof typeof categoryConfig].label}</h4>
                                <ul className="space-y-1 text-sm list-disc list-inside">
                                    {files.map((f: any, i) => <li key={i} className="text-gray-300"><span className="text-cyan-400 font-mono text-xs">{f.fileName}</span></li>)}
                                </ul>
                            </div> );
                        })}
                    </div>
                    <div className="text-center">
                        <button onClick={handleDownloadAll} disabled={isZipping} className="flex items-center justify-center gap-3 bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 px-8 rounded-2xl transition-all disabled:opacity-50 w-full sm:w-auto mx-auto">
                            {isZipping ? <><SpinnerIcon className="w-5 h-5 animate-spin"/><span>Gerando...</span></> : <><ArrowDownTrayIcon className="w-5 h-5" /><span>Baixar .zip</span></>}
                        </button>
                    </div>
                </div>
            );
        }
        
        if (activeCategory === 'certidoes') {
             if (selectedCertidaoKey) {
                const isEstadual = selectedCertidaoKey === 'estadual';
                let statusOverride: CertidaoStatusInfo | undefined = undefined;

                if (isEstadual) {
                    const situacao = cadespData.situacao;
                    const isActive = situacao.toLowerCase() === 'ativo';
                    statusOverride = isActive 
                        ? { text: 'Ativa', color: 'border-green-500/50 bg-green-500/10 text-green-400' }
                        : { text: 'Inativa', color: 'border-red-500/50 bg-red-500/10 text-red-400' };
                }

                return (
                    <div className="animate-fade-in">
                        <button onClick={() => setSelectedCertidaoKey(null)} className="flex items-center gap-2 text-sm font-bold text-gray-400 hover:text-yellow-500 transition-all group mb-6">
                            <div className="p-2 bg-gray-900 rounded-xl border border-gray-800 group-hover:border-yellow-600/30"><ArrowLeftIcon className="w-5 h-5" /></div>
                            Voltar para o Painel de Certidões
                        </button>
                        <CertidaoDetailView 
                            title={certidaoTabConfig[selectedCertidaoKey as keyof typeof certidaoTabConfig]?.label || selectedCertidaoKey} 
                            certKey={selectedCertidaoKey}
                            certidao={(habilitacaoData.certidoes?.[selectedCertidaoKey as keyof typeof habilitacaoData.certidoes] || {}) as Certidao} 
                            isProcessingAI={isProcessingAI === selectedCertidaoKey} 
                            isUpdating={isSearchingLink === selectedCertidaoKey} 
                            onFileUpload={(e) => handleFileUploadCertidao(e, selectedCertidaoKey)} 
                            onRemoveFile={() => handleUpdateCertidao(selectedCertidaoKey, { fileData: null, fileName: null, issueDate: null, expiryDate: null })} 
                            onAutoUpdate={() => handleAutoUpdate(selectedCertidaoKey)}
                            onUpdateDates={(dates) => handleUpdateCertidao(selectedCertidaoKey, dates)}
                            statusOverride={statusOverride}
                        >
                           {isEstadual && (
                             <div className="bg-gray-900 rounded-3xl border border-gray-800 p-8">
                               <h3 className="text-xl font-bold text-white mb-4">Consulta CADESP</h3>
                               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                 <DataField label="IE" value={<p className="font-mono">{cadespData.ie}</p>} />
                                 <DataField label="CNPJ" value={<p className="font-mono">{cadespData.cnpj}</p>} />
                                 <DataField label="Situação" value={<span className={`font-bold ${(cadespData.situacao.toLowerCase() === 'ativo') ? 'text-green-400' : 'text-red-400'}`}>{cadespData.situacao}</span>} />
                                 <DataField label="Data da Inscrição" value={cadespData.dataInscricao} />
                               </div>
                               <DataField label="Nome Empresarial" value={cadespData.nomeEmpresarial} className="mt-4" />
                             </div>
                           )}
                        </CertidaoDetailView>
                    </div>
                );
             }

            return (
                <div className="bg-gray-900 rounded-3xl border border-gray-800 shadow-xl p-8 space-y-4">
                    {Object.entries(certidaoTabConfig).map(([key, { label }]) => {
                        if (key === 'estadual') {
                            const situacao = cadespData.situacao;
                            const isActive = situacao.toLowerCase() === 'ativo';
                            const status: CertidaoStatusInfo = isActive 
                                ? { text: 'Ativa', color: 'border-green-500/50 bg-green-500/10 text-green-400' }
                                : { text: 'Inativa', color: 'border-red-500/50 bg-red-500/10 text-red-400' };

                            return (
                                <button key={key} onClick={() => setSelectedCertidaoKey(key)} className="w-full text-left bg-black/20 p-4 rounded-2xl border border-gray-800/60 hover:bg-yellow-600/5 hover:border-yellow-500/30 transition-all flex items-center gap-4">
                                    <div className="flex-grow">
                                        <p className="font-bold text-white">{label}</p>
                                        <p className="text-xs text-gray-500 font-mono">Situação: <span className={isActive ? 'text-green-400 font-bold' : 'text-red-400 font-bold'}>{situacao}</span></p>
                                    </div>
                                    <StatusBadge status={status} />
                                </button>
                            );
                        }

                        const cert = (habilitacaoData.certidoes?.[key as keyof typeof habilitacaoData.certidoes] || {}) as Certidao;
                        const status = getCertidaoStatus(cert?.expiryDate, key);
                        return (
                            <button key={key} onClick={() => setSelectedCertidaoKey(key)} className="w-full text-left bg-black/20 p-4 rounded-2xl border border-gray-800/60 hover:bg-yellow-600/5 hover:border-yellow-500/30 transition-all flex items-center gap-4">
                                <div className="flex-grow">
                                    <p className="font-bold text-white">{label}</p>
                                    <p className="text-xs text-gray-500 font-mono">Vencimento: {formatDate(cert?.expiryDate)}</p>
                                </div>
                                <StatusBadge status={status} />
                            </button>
                        );
                    })}
                </div>
            );
        }

        const categoryKey = activeCategory as keyof HabilitacaoData;
        return (
            <div className="animate-fade-in">
                 <FileCategoryView title={categoryConfig[categoryKey as keyof typeof categoryConfig]?.label || activeCategory} files={(habilitacaoData[categoryKey] as ManagedFile[]) || []} onAddFile={(file) => handleAddFile(categoryKey, file)} onRemoveFile={(id) => handleRemoveFile(categoryKey, id)} onUpdateFile={(id, desc) => handleUpdateFile(categoryKey, id, desc)} />
            </div>
        )
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            <nav className="md:col-span-3 lg:col-span-2 space-y-3">
                {Object.entries(categoryConfig).map(([key, { label, icon }]) => (
                    <NavButton key={key} label={label} icon={icon} isActive={activeCategory === key} onClick={() => { setActiveCategory(key); setSelectedCertidaoKey(null); }} />
                ))}
            </nav>
            <main className="md:col-span-9 lg:col-span-10">
                {renderContent()}
            </main>
        </div>
    );
};
