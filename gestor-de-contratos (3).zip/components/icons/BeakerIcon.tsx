
import React from 'react';

export const BeakerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v1.244c0 .892-.567 1.686-1.392 1.908-.593.16-1.174.399-1.73.712-.628.352-1.028 1.023-1.028 1.739v6.237a.75.75 0 00.111.394l3.586 5.976C10.22 21.41 11.08 22 12.015 22h0c.933 0 1.793-.59 2.128-1.487l3.586-5.976a.75.75 0 00.111-.394v-6.237c0-.716-.4-1.387-1.028-1.739-.556-.313-1.137-.552-1.73-.712-.825-.222-1.392-1.016-1.392-1.908V3.104Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 10h6M10 13h4M11 16h2" />
  </svg>
);
