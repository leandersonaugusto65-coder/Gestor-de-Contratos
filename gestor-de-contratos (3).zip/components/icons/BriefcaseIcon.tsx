
import React from 'react';
export const BriefcaseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.15v4.075c0 1.313-.954 2.5-2.243 2.5-1.29 0-2.25-.95-2.25-2.25S16.71 14 18 14v-4.075c0-1.313.954-2.5 2.243-2.5 1.29 0 2.25.95 2.25 2.25S21.29 14 20 14zM3.75 14.15v4.075c0 1.313.954 2.5 2.243 2.5 1.29 0 2.25-.95 2.25-2.25S7.29 14 6 14v-4.075c0-1.313-.954-2.5-2.243-2.5C2.46 7.425 1.5 8.375 1.5 9.675S2.71 14 4 14zm4.5 0v4.075c0 1.313.954 2.5 2.243 2.5 1.29 0 2.25-.95 2.25-2.25S11.79 14 10.5 14v-4.075c0-1.313-.954-2.5-2.243-2.5C6.96 7.425 6 8.375 6 9.675S7.21 14 8.5 14z" />
  </svg>
);
