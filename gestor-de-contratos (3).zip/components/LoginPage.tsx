import React, { useState } from 'react';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { ResetPasswordModal } from './ResetPasswordModal';
import { LogoPlaceholder } from './icons/LogoPlaceholder';

// Icons for password visibility
const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const EyeSlashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.243 4.243L6.228 6.228" />
  </svg>
);

interface LoginPageProps {
  supabaseClient: SupabaseClient;
}

type ActiveTab = 'login' | 'register';

export const LoginPage: React.FC<LoginPageProps> = ({ supabaseClient }) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('login');
  
  // Preenche os dados de login conforme solicitado
  const [email, setEmail] = useState('oficinacomprasnet@gmail.com');
  const [password, setPassword] = useState('11');
  
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  
  const resetFormState = () => {
      setEmail('oficinacomprasnet@gmail.com');
      setPassword('11');
      setName('');
      setError(null);
      setMessage(null);
      setShowPassword(false);
  }

  const handleTabChange = (tab: ActiveTab) => {
      setActiveTab(tab);
      resetFormState();
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setIsLoading(true);

    const { error } = await supabaseClient.auth.signInWithPassword({ email, password });

    if (error) {
        if (error.message.includes('Email not confirmed')) {
            setError('Seu e-mail ainda não foi confirmado. Verifique sua caixa de entrada.');
        } else if (error.message.includes('Invalid login credentials')) {
            setError('E-mail ou senha inválidos.');
        } else {
            setError('Não foi possível fazer login. Tente novamente.');
        }
    }
    setIsLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres para novos cadastros.');
      return;
    }
    
    setIsLoading(true);
    const { error } = await supabaseClient.auth.signUp({
        email, 
        password,
        options: {
            data: {
                full_name: name,
            }
        }
    });

    if (error) {
        setError(error.message);
    } else {
        setMessage('Cadastro realizado! Verifique seu e-mail para confirmar sua conta.');
        setActiveTab('login');
        resetFormState();
    }
    setIsLoading(false);
  }

  type TabButtonProps = { tab: ActiveTab; children: React.ReactNode; };
  const TabButton: React.FC<TabButtonProps> = ({ tab, children }) => (
    <button
      type="button"
      onClick={() => handleTabChange(tab)}
      className={`relative w-full py-3 text-sm font-bold uppercase tracking-widest transition-all duration-300 rounded-xl border-2 ${
        activeTab === tab 
          ? 'bg-yellow-600/10 border-yellow-500 text-white shadow-[0_0_15px_rgba(202,138,4,0.15)]' 
          : 'bg-transparent border-transparent text-gray-500 hover:text-gray-300'
        }`
      }
    >
      {activeTab === tab && <div className="absolute inset-0 bg-gradient-to-r from-yellow-600/5 to-transparent" />}
      <span className="relative z-10">{children}</span>
    </button>
  );

  return (
    <>
      <div className="min-h-screen flex flex-col justify-center items-center bg-black p-4 font-sans">
        <div className="w-full max-w-sm mx-auto bg-gray-900 rounded-2xl shadow-2xl border border-gray-800 overflow-hidden animate-fade-in-up">
          <div className="flex flex-col items-center pt-10 pb-6">
              <LogoPlaceholder className="h-20 w-20 mb-4 shadow-lg" />
              <h1 className="text-2xl font-bold text-gray-100">Oficina da Arte</h1>
              <p className="text-gray-400 text-sm mt-1">Gestão de Contratos</p>
          </div>

          <div className="px-6 pb-2">
              <div className="flex space-x-2 p-1 bg-black/40 rounded-2xl border border-gray-800">
                  <TabButton tab="login">Entrar</TabButton>
                  <TabButton tab="register">Criar</TabButton>
              </div>
          </div>

          <div className="p-6">
              {message && (<p className="text-sm text-green-300 bg-green-500/10 p-3 rounded-lg border border-green-500/20 mb-4 text-center">{message}</p>)}
              {error && (<p className="text-sm text-red-300 bg-red-500/10 p-3 rounded-lg border border-red-500/20 mb-4 text-center">{error}</p>)}

              {activeTab === 'login' ? (
                   <form onSubmit={handleLogin} className="space-y-5" autoComplete="off">
                      <div>
                        <label htmlFor="email-login" className="block text-sm font-medium text-gray-300 mb-1">E-mail</label>
                        <input 
                            id="email-login" 
                            name="email" 
                            type="email" 
                            autoComplete="username" 
                            required 
                            value={email} 
                            onChange={(e) => setEmail(e.target.value)} 
                            className="input-style" 
                        />
                      </div>

                      <div>
                        <div className="flex justify-between items-baseline mb-1">
                          <label htmlFor="password-login" className="block text-sm font-medium text-gray-300">Senha</label>
                          <button type="button" onClick={() => setIsResettingPassword(true)} className="text-xs text-amber-500 hover:text-amber-400 font-semibold">Esqueceu a senha?</button>
                        </div>
                        <div className="relative">
                          <input 
                            id="password-login" 
                            name="password" 
                            type={showPassword ? 'text' : 'password'} 
                            autoComplete="current-password" 
                            required 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                            className="input-style" 
                          />
                          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-200">
                            {showPassword ? <EyeSlashIcon className="h-5 w-5"/> : <EyeIcon className="h-5 w-5"/>}
                          </button>
                        </div>
                      </div>

                      <div className="pt-2">
                        <button type="submit" disabled={isLoading} className="button-primary">
                            {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : 'Entrar na Plataforma'}
                        </button>
                      </div>
                  </form>
              ) : (
                  <form onSubmit={handleRegister} className="space-y-4" autoComplete="off">
                      <div>
                          <label htmlFor="register-name" className="block text-sm font-medium text-gray-300 mb-1">Nome Completo</label>
                          <input id="register-name" name="name" type="text" autoComplete="off" required value={name} onChange={(e) => setName(e.target.value)} className="input-style" />
                      </div>
                      <div>
                          <label htmlFor="register-email" className="block text-sm font-medium text-gray-300 mb-1">E-mail</label>
                          <input id="register-email" name="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input-style" />
                      </div>
                      <div>
                          <label htmlFor="register-password" className="block text-sm font-medium text-gray-300 mb-1">Senha</label>
                          <input id="register-password" name="password" type="password" autoComplete="new-password" required value={password} onChange={(e) => setPassword(e.target.value)} className="input-style" />
                          <p className="text-xs text-gray-500 mt-1">Mínimo de 6 caracteres.</p>
                      </div>
                      <div className="pt-2">
                        <button type="submit" disabled={isLoading} className="button-primary">
                            {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : 'Criar minha Conta'}
                        </button>
                      </div>
                  </form>
              )}
          </div>
        </div>
        <style>{`
          .input-style { appearance: none; display: block; width: 100%; padding: 0.75rem; border: 1px solid #374151; border-radius: 0.75rem; background-color: #000000; color: #f9fafb; transition: all 0.2s; }
          .input-style:focus { outline: none; border-color: #f59e0b; box-shadow: 0 0 0 1px rgba(245, 158, 11, 0.2); }
          .button-primary { width: 100%; display: flex; justify-content: center; padding: 0.75rem 1rem; border: none; border-radius: 0.75rem; font-size: 0.875rem; line-height: 1.25rem; font-weight: 700; color: #000000; background: #eab308; box-shadow: 0 4px 12px rgba(234, 179, 8, 0.3); transition: all 0.3s; }
          .button-primary:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 15px rgba(234, 179, 8, 0.4); background: #ca8a04; }
          .button-primary:active:not(:disabled) { transform: scale(0.98); }
          .button-primary:disabled { opacity: 0.5; cursor: not-allowed; }
          @keyframes fade-in-up { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
          .animate-fade-in-up { animation: fade-in-up 0.4s ease-out forwards; }
        `}</style>
      </div>
      {isResettingPassword && (
          <ResetPasswordModal 
            supabaseClient={supabaseClient} 
            onClose={() => setIsResettingPassword(false)} 
            onSuccess={(msg) => { setMessage(msg); setIsResettingPassword(false); }} 
          />
      )}
    </>
  );
};