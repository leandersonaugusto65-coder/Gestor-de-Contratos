
import React, { useState, useEffect, useCallback } from 'react';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Profile, GitHubConfig } from '../types';
import { XMarkIcon } from './icons/XMarkIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { CheckIcon } from './icons/CheckIcon';
import { GlobeAltIcon } from './icons/GlobeAltIcon';
import { UserGroupIcon } from './icons/UserGroupIcon';
import { CloudArrowUpIcon } from './icons/CloudArrowUpIcon';
import { ArrowPathIcon } from './icons/ArrowPathIcon';

interface AdminPanelProps {
  supabase: SupabaseClient;
  onClose: () => void;
  githubConfig: GitHubConfig;
  onUpdateGitHubConfig: (config: GitHubConfig) => void;
  onForceSync: () => void;
  isSyncing: boolean;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ supabase, onClose, githubConfig, onUpdateGitHubConfig, onForceSync, isSyncing }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'github'>('users');
  const [users, setUsers] = useState<Profile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updatingUserId, setUpdatingUserId] = useState<string | null>(null);

  const fetchUsers = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('email', { ascending: true });

    if (error) {
      setError('Não foi possível carregar os usuários. Verifique se você tem permissão de administrador.');
      console.error(error);
    } else {
      setUsers(data);
    }
    setIsLoading(false);
  }, [supabase]);

  useEffect(() => {
    if (activeTab === 'users') fetchUsers();
  }, [activeTab, fetchUsers]);

  const handlePermissionChange = async (userId: string, newPermission: string) => {
    let newRole: 'editor' | 'user' = 'user';
    let newApprovalStatus = false;

    if (newPermission === 'editor') {
        newRole = 'editor';
        newApprovalStatus = true;
    } else if (newPermission === 'user') {
        newRole = 'user';
        newApprovalStatus = true;
    } 
    
    setUpdatingUserId(userId);
    const { data: updatedUser, error } = await supabase
        .from('profiles')
        .update({ role: newRole, is_approved: newApprovalStatus })
        .eq('id', userId)
        .select()
        .single();
    
    if (error) {
        console.error("Error updating user:", error);
        setError(`Falha ao atualizar o usuário ${userId}.`);
    } else if(updatedUser) {
        setUsers(currentUsers => 
            currentUsers.map(u => u.id === userId ? updatedUser : u)
        );
    }
    setUpdatingUserId(null);
  };
  
  const getPermissionValue = (user: Profile): string => {
    if (!user.is_approved) return 'pending';
    if (user.role === 'editor') return 'editor';
    if (user.role === 'user') return 'user';
    return 'pending'; 
  }

  const handleGitHubChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    onUpdateGitHubConfig({
      ...githubConfig,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex justify-center items-center p-4 backdrop-blur-md">
      <div className="bg-gray-800 border border-gray-700 rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-fade-in-up">
        <header className="p-6 border-b border-gray-700 flex justify-between items-center bg-gray-900/80">
          <div className="flex items-center gap-4">
             <div className="p-3 bg-yellow-500/10 rounded-2xl">
                <UserGroupIcon className="w-6 h-6 text-yellow-500" />
             </div>
             <h2 className="text-xl font-bold text-white uppercase tracking-tighter">Administração</h2>
          </div>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-white transition-colors">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </header>

        {/* TAB NAVIGATION */}
        <div className="px-6 pt-4 bg-gray-900/40 border-b border-gray-700/50">
            <div className="flex gap-2 mb-4">
                <button 
                  onClick={() => setActiveTab('users')}
                  className={`flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'users' ? 'bg-yellow-500 text-black shadow-lg' : 'bg-gray-800 text-gray-500 hover:bg-gray-700'}`}
                >
                    <UserGroupIcon className="w-4 h-4" />
                    Usuários
                </button>
                <button 
                  onClick={() => setActiveTab('github')}
                  className={`flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'github' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-gray-800 text-gray-500 hover:bg-gray-700'}`}
                >
                    <CloudArrowUpIcon className="w-4 h-4" />
                    GitHub Sync
                </button>
            </div>
        </div>

        <div className="p-6 flex-grow overflow-y-auto bg-gray-900/20">
          {activeTab === 'users' ? (
            isLoading ? (
              <div className="flex justify-center items-center py-20">
                <SpinnerIcon className="w-10 h-10 animate-spin text-yellow-500" />
              </div>
            ) : error ? (
              <p className="text-center text-red-500 bg-red-500/10 p-4 rounded-2xl border border-red-500/20">{error}</p>
            ) : (
              <div className="space-y-3">
                {users.map(user => (
                  <div key={user.id} className="bg-gray-800/60 border border-gray-700/50 rounded-2xl p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4 transition-all hover:bg-gray-800">
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-white truncate" title={user.full_name}>{user.full_name || '(Nome não informado)'}</p>
                      <p className="text-xs text-gray-500 font-mono truncate" title={user.email}>{user.email}</p>
                    </div>
                    <div className="flex items-center gap-3 w-full sm:w-auto">
                      {updatingUserId === user.id && <SpinnerIcon className="w-4 h-4 animate-spin text-yellow-500" />}
                      {user.role === 'admin' ? (
                          <span className="text-[10px] font-black text-yellow-500 bg-yellow-900/30 px-4 py-2 rounded-full border border-yellow-500/20 uppercase tracking-widest">Admin</span>
                      ) : (
                        <select 
                          value={getPermissionValue(user)}
                          onChange={(e) => handlePermissionChange(user.id, e.target.value)}
                          disabled={updatingUserId === user.id}
                          className="w-full sm:w-44 text-[10px] font-black uppercase tracking-widest py-2 px-3 rounded-xl border border-gray-600 bg-gray-900 text-gray-300 focus:ring-yellow-500 focus:border-yellow-500"
                        >
                            <option value="editor">✓ Aprovado (Editor)</option>
                            <option value="user">✓ Aprovado (Leitura)</option>
                            <option value="pending">⏳ Pendente</option>
                        </select>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            <div className="space-y-8 animate-fade-in pb-10">
                <div className="bg-emerald-600/10 border border-emerald-600/20 rounded-2xl p-6 flex items-start gap-4">
                    <div className="p-3 bg-emerald-600/20 rounded-2xl">
                        <CloudArrowUpIcon className="w-8 h-8 text-emerald-500" />
                    </div>
                    <div>
                        <h3 className="text-emerald-500 font-black uppercase tracking-widest text-sm">Backup em Tempo Real</h3>
                        <p className="text-gray-400 text-xs mt-1 leading-relaxed">Cada alteração salva será espelhada em um arquivo JSON no seu repositório do GitHub automaticamente.</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-6">
                    <div className="flex items-center justify-between p-4 bg-black/40 rounded-2xl border border-gray-700">
                        <span className="text-sm font-bold text-gray-200">Ativar Sincronização Automática</span>
                        <input 
                            type="checkbox" 
                            name="enabled" 
                            checked={githubConfig.enabled} 
                            onChange={handleGitHubChange}
                            className="w-6 h-6 rounded-lg border-gray-700 bg-gray-900 text-emerald-500 focus:ring-0 cursor-pointer"
                        />
                    </div>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 ml-1 tracking-widest">GitHub Personal Access Token (PAT)</label>
                            <input 
                                type="password" 
                                name="token" 
                                value={githubConfig.token} 
                                onChange={handleGitHubChange} 
                                className="w-full bg-black/40 border border-gray-700 rounded-2xl px-5 py-3 text-white focus:border-emerald-500 outline-none transition-all font-mono text-sm" 
                                placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 ml-1 tracking-widest">Usuário (Owner)</label>
                                <input 
                                    type="text" 
                                    name="owner" 
                                    value={githubConfig.owner} 
                                    onChange={handleGitHubChange} 
                                    className="w-full bg-black/40 border border-gray-700 rounded-2xl px-5 py-3 text-white focus:border-emerald-500 outline-none transition-all text-sm" 
                                    placeholder="ex: oficina-arte"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 ml-1 tracking-widest">Repositório (Repo)</label>
                                <input 
                                    type="text" 
                                    name="repo" 
                                    value={githubConfig.repo} 
                                    onChange={handleGitHubChange} 
                                    className="w-full bg-black/40 border border-gray-700 rounded-2xl px-5 py-3 text-white focus:border-emerald-500 outline-none transition-all text-sm" 
                                    placeholder="ex: backup-dados"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 ml-1 tracking-widest">Caminho do Arquivo</label>
                                <input 
                                    type="text" 
                                    name="path" 
                                    value={githubConfig.path} 
                                    onChange={handleGitHubChange} 
                                    className="w-full bg-black/40 border border-gray-700 rounded-2xl px-5 py-3 text-white focus:border-emerald-500 outline-none transition-all text-sm" 
                                    placeholder="database.json"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 ml-1 tracking-widest">Branch</label>
                                <input 
                                    type="text" 
                                    name="branch" 
                                    value={githubConfig.branch} 
                                    onChange={handleGitHubChange} 
                                    className="w-full bg-black/40 border border-gray-700 rounded-2xl px-5 py-3 text-white focus:border-emerald-500 outline-none transition-all text-sm" 
                                    placeholder="main"
                                />
                            </div>
                        </div>
                        
                        <div className="pt-2">
                             <button 
                                type="button" 
                                onClick={onForceSync}
                                disabled={isSyncing || !githubConfig.enabled || !githubConfig.token}
                                className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-30 text-white font-black py-4 rounded-2xl uppercase text-xs tracking-widest transition-all shadow-lg active:scale-95"
                             >
                                {isSyncing ? <SpinnerIcon className="w-4 h-4 animate-spin" /> : <ArrowPathIcon className="w-4 h-4" />}
                                {isSyncing ? 'Sincronizando...' : 'Salvar e Sincronizar Agora'}
                             </button>
                        </div>
                    </div>

                    {githubConfig.error && (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-xs font-bold uppercase tracking-widest text-center">
                            Erro no GitHub: {githubConfig.error}
                        </div>
                    )}

                    {/* AJUDA PARA O USUÁRIO */}
                    <div className="p-6 bg-gray-900 border border-gray-700 rounded-2xl space-y-4">
                        <h4 className="text-white font-bold text-xs uppercase">Como resolver problemas de conexão?</h4>
                        <ul className="text-[11px] text-gray-400 space-y-2 list-disc ml-4">
                            <li>Certifique-se de que o **Repositório** já existe no seu GitHub.</li>
                            <li>O **Token (PAT)** precisa ter permissão de <code className="text-emerald-500 bg-black px-1">Contents: Write</code>.</li>
                            <li>Se o repositório estiver vazio, crie um arquivo <code className="text-gray-200">README.md</code> manualmente pelo site primeiro.</li>
                            <li>Verifique se o **Owner** é o seu nome de usuário e não o nome da organização (a menos que o repo pertença à org).</li>
                        </ul>
                    </div>
                    
                    {githubConfig.lastSync && (
                        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-emerald-500 text-[10px] font-black uppercase tracking-[0.2em] text-center">
                            Sincronizado pela última vez: {new Date(githubConfig.lastSync).toLocaleString()}
                        </div>
                    )}
                </div>
            </div>
          )}
        </div>
        
        <footer className="bg-gray-900 border-t border-gray-700 p-6 flex justify-end">
          <button type="button" onClick={onClose} className="px-10 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold text-sm rounded-2xl transition-all shadow-xl active:scale-95">
            Fechar Painel
          </button>
        </footer>
      </div>
      <style>{`
          @keyframes fade-in-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
          .animate-fade-in-up { animation: fade-in-up 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};
