
import { GitHubConfig } from '../types';

/**
 * Converte string para Base64 de forma segura com UTF-8
 */
const toBase64 = (str: string) => {
  try {
    // Método robusto para lidar com acentos e caracteres especiais no Base64
    const bytes = new TextEncoder().encode(str);
    const binString = Array.from(bytes, (byte) => String.fromCharCode(byte)).join("");
    return btoa(binString);
  } catch (e) {
    return btoa(unescape(encodeURIComponent(str)));
  }
};

export const syncToGitHub = async (config: GitHubConfig, data: any) => {
  if (!config.enabled || !config.token || !config.owner || !config.repo) {
    return { success: false, error: 'Configuração incompleta no Painel Admin.' };
  }

  const { token, owner, repo, path, branch } = config;
  const fileName = path || 'database.json';
  const targetBranch = branch || 'main';
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${fileName}`;
  
  const commonHeaders = {
    'Authorization': `Bearer ${token}`,
    'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28'
  };

  try {
    // 1. Tentar pegar o SHA do arquivo existente (necessário para update)
    let sha: string | null = null;
    const getRes = await fetch(`${url}?ref=${targetBranch}`, {
      headers: commonHeaders
    });

    if (getRes.status === 200) {
      const fileData = await getRes.json();
      sha = fileData.sha;
    } else if (getRes.status === 404) {
      console.log('Arquivo não existe ainda, será criado um novo.');
    } else if (getRes.status === 401) {
      throw new Error('Token inválido ou expirado (Erro 401).');
    } else if (getRes.status === 403) {
      throw new Error('Sem permissão. Verifique se o Token tem acesso de "Write" ao repositório.');
    }

    // 2. Preparar conteúdo
    const jsonString = JSON.stringify(data, null, 2);
    const contentBase64 = toBase64(jsonString);

    const body = {
      message: `Sync automático: ${new Date().toLocaleString('pt-BR')}`,
      content: contentBase64,
      branch: targetBranch,
      ...(sha ? { sha } : {})
    };

    // 3. Executar o salvamento (PUT)
    const putRes = await fetch(url, {
      method: 'PUT',
      headers: {
        ...commonHeaders,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body)
    });

    const responseData = await putRes.json();

    if (!putRes.ok) {
      // Traduzindo erros comuns para o usuário
      if (responseData.message?.includes('is not a file')) throw new Error('O caminho especificado já existe como uma pasta.');
      if (putRes.status === 404) throw new Error('Repositório ou Branch não encontrados. Verifique os nomes.');
      if (putRes.status === 409) throw new Error('Conflito de edição (SHA mismatch). Tente sincronizar novamente.');
      
      throw new Error(responseData.message || `Erro ${putRes.status} ao salvar no GitHub.`);
    }

    return { success: true, lastSync: new Date().toISOString() };
  } catch (err: any) {
    console.error('GitHub Sync Detailed Error:', err);
    return { success: false, error: err.message };
  }
};
